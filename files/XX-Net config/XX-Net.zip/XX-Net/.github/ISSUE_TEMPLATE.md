
* 是否试过最新的版本 (https://github.com/XX-net/XX-Net/releases)？


* 是否查看过 Wiki (https://github.com/XX-net/XX-Net/wiki)？


* 描述遇到的问题，贴出所有能帮助分析问题的状态页和日志：


* 如果问题得到解决，请务必回复相关情况，谢谢。
