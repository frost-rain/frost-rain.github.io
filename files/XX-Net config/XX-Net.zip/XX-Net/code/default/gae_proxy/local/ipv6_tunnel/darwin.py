#!/usr/bin/env python2
# coding:utf-8

import os
import sys
from .common import *


def state():
    return "Developing"


def state_pp():
    return "Developing"


def switch_pp():
    return "Developing"


def enable(is_local=False):
    return "Developing"


def disable(is_local=False):
    return "Developing"


def set_best_server(is_local=False):
    return "Developing"
